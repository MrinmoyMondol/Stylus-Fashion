@extends('admin.admin_layout')

@section('title')

Admin || View Product
@endsection


@section('admin_content')
<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a>
					<i class="icon-angle-right"></i> 
				</li>
				<li>
					<i class="icon-edit"></i>
					<a href="#"> Product Details</a>
				</li>
			</ul>

			<div class="row-fluid ">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon edit"></i><span class="break"></span> Product Details</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">

						<table class="table table-hover">
                            <tbody>
                                <tr>
                                    <td class="success">Product ID: </td>
                                    <td>{{$product->product_id}}</td>
                                </tr>
                                <tr>
                                    <td class="success">Product Name: </td>
                                    <td>{{$product->product_name}}</td>
                                </tr>
                                <tr>
                                    <td class="success">Category Name: </td>
                                    <td>{{$product->category_name}}</td>
                                </tr>
                                <tr>
                                    <td class="success">Manufacture Name: </td>
                                    <td>{{$product->manufacture_name}} </td>
                                </tr>
                                <tr>
                                    <td class="success">Upload Date : </td>
                                    <td>{{$product->upload_date}}</td>
                                </tr>
                                <tr>
                                    <td class="success">Product Short Description: </td>
                                    <td>{{$product->product_short_description}}</td>
                                </tr>
                                <tr>
                                    <td class="success">Product Long Description: </td>
                                    <td>{{$product->product_long_description}}</td>
                                </tr>
                                <tr>
                                    <td class="success">Product Price: </td>
                                    <td>{{$product->product_price}}</td>
                                </tr>
                                <tr>
                                    <td class="success">Product Image: </td>
                                    <td><img src="{{asset($product->product_image)}}" alt="{{$product->product_name}}" width="100" height="100"></td>
                                </tr>
                                <tr>
                                    <td class="success">Product Size: </td>
                                    <td>{{$product->product_size}}</td>
                                </tr>
                                <tr>
                                    <td class="success">Product Quantity: </td>
                                    <td>{{$product->product_quantity}}</td>
                                </tr>

                                <tr>
                                    <td class="success">Product Color: </td>
                                    <td>{{$product->product_color}}</td>
                                </tr>
                                 <tr>
                                    <td class="success">Publication Status: </td>
                                    <td>{{$product->publicationStatus == 1 ? 'Published' : 'Unpublished' }}</td>
                                </tr>
                            </tbody>
                        </table>

                        <a href="{{url('/manegeProduct')}}" class="btn btn-primary" id="back"><i class="halflings-icon arrow-left"></i>Back</a>
					  

					</div>
				</div><!--/span-->

				

			</div><!--/row-->
@endsection