@extends('layout')
 



@section('content')
 <section id="cart_items">
		<div class="container">		

			
			<div class="review-payment">
				<h2>Payment Details</h2>
			</div>
			<div class="col-sm-10">
				<div class="table-responsive cart_info">
					<table class="table table-condensed">
						<thead>
                        <tr class="cart_menu">
                            <td class="image">Image</td>
                            <td></td>
                            <td></td>
                            <td class="description">Name</td>
                            <td class="price">Price</td>
                            <td class="quantity">Quantity</td>
                            <td class="total">Total</td>
                            <td>Action</td>
                        </tr>
                    </thead>
						<tbody>
							<tr>
								@foreach($cartProducts as $cartProduct)
                            
                            <td class="cart_product">
                                <a href=""><img src="{{asset($cartProduct->options->image)}}" alt="" width="100px" height="100px"></a>
                            </td>
                            <td></td>
                            <td></td>
								<td class="cart_description">
                                <h4><a href="">{{$cartProduct->name}}</a></h4>
                                <p>Web ID: {{$cartProduct->id}}</p>
                            </td>
								<td class="cart_price">
                                <p>BDT. {{$cartProduct->price}}</p>
                            </td>
								 <form action="{{url('/cart-update')}}" method="post" >
                                {{csrf_field() }}
                            <td class="cart_quantity">
                                <div class="cart_quantity_button">
                                    
                                    <input class="cart_quantity_input" type="text" name="qty" value="{{$cartProduct->qty}}" autocomplete="off" size="2">

                                     <input  type="hidden" name="cart_rowId" value="{{$cartProduct->rowId}}" >
                                    
                                    <button class="btn btn-primary" type="submit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
 
                                </div>
                            </td>
                            </form>

								<td class="cart_total">
                                <p class="cart_total_price"> BDT. {{$cartProduct->total}}</p>
                            </td>
                            <td class="cart_delete">
                                <a class="cart_quantity_delete" href="{{url('/delete-cart-product/'.$cartProduct->rowId)}}"><i class="fa fa-times"></i></a>
                            </td>

                            @endforeach
							</tr>


							<tr>
								<td colspan="4">&nbsp;</td>
								<td colspan="2">
									<table class="table table-condensed total-result">
										<tr>
											<td>Cart Sub Total</td>
											<td>BDT. {{Cart::subtotal()}}</td>
										</tr>
										<tr>
											<td>Exo Tax</td>
											<td>BDT. {{Cart::tax()}}</td>
										</tr>
										<tr class="shipping-cost">
											<td>Shipping Cost</td>
											<td> BDT. Free</td>										
										</tr>
										<tr>
											<td>Total</td>
											<td><span>BDT. {{Cart::total()}}</span></td>
										</tr>
									</table>

									
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			
		</div>
	</section> <!--/#cart_items--> 

<section id="do_action">
	<div class="container">
	<div class="row">

		<form action="{{url('/orderPlace')}}" method="post">
			{{csrf_field()}}
		<div class="paymentCont col-sm-8">
			<div class="headingWrap">
				<h3 class="headingTop text-center">Select Your Payment Method</h3>	
					
			</div>
			<div class="paymentWrap">
				<div class="btn-group paymentBtnGroup btn-group-justified" data-toggle="buttons">
		            <label class="btn paymentMethod active">
		            	<div class="method visa"></div>
		                <input type="radio" name="payment_gateway"  value="handCash" checked> 
		            </label>
		            <label class="btn paymentMethod">
		            	<div class="method master-card"></div>
		                <input type="radio" name="payment_gateway" value="card"> 
		            </label>
		            <label class="btn paymentMethod">
	            		<div class="method amex"></div>
		                <input type="radio" name="payment_gateway" value="bKash">
		            </label>
		             <label class="btn paymentMethod">
	             		<div class="method vishwa"></div>
		                <input type="radio" name="payment_gateway" value="payza"> 
		            </label>
		           
		         
		        </div>        
			</div>
			<div class="footerNavWrap clearfix">
				

				<input type="submit" class="btn btn-success pull-right btn-fyi" value="SUBMIT">
			</div>
		</div>

</form>






		
	</div>
</div>
</section><!--/#do_action-->    
                
@endsection


