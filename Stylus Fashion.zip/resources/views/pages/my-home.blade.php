@extends('layout')


@section('content')

<p>Your Order is Successfully Completed...!!!</p>

@endsection