<?php
 
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('layout');
// });


//FrontEnd Site......................

Route::get('/' , 'HomeController@index');

Route::get('/productByCategory/{category_id}','HomeController@showProductByCategory');
Route::get('/productByManufacture/{manufacture_id}','HomeController@showProductByManufacture');

Route::get('/viewProduct/{product_id}','HomeController@viewProduct');



//Cart Route..............
Route::post('/addToCart','CartController@addToCart');
Route::get('/showCart','CartController@showCart');
Route::post('/cart-update','CartController@updateCart');
Route::get('/delete-cart-product/{rowId}','CartController@deleteCart');


//CheckOut Route...........

Route::get('/loginCheck','CheckoutController@login_check');
Route::post('/customer_registration','CheckoutController@customer_registration');
Route::post('/login_customer','CheckoutController@login_customer');
Route::get('/checkout','CheckoutController@checkOut');
Route::get('/customerLogout','CheckoutController@customerLogout');




//Shipping Route............
Route::post('/saveShippingDetails','CheckoutController@saveShippingDetails');




//Payment Route..........
Route::get('/payment','PaymentController@index');
Route::post('/orderPlace','PaymentController@orderPlace');



Route::get('/my-home','PaymentController@myHome');








//BackEnd Site.....................

Route::get('/admin' , 'AdminController@index');
Route::get('/shopLogo' , 'AdminController@shopLogo');
Route::post('/saveLogo' , 'AdminController@saveLogo');
Route::get('/dashboard' , 'SuperAdminController@index');
Route::post('/admin_dashboard' , 'AdminController@dashboard');
Route::get('/logout' , 'SuperAdminController@logout');



//Ctegory Route...........

Route::get('/add-category' , 'CategoryController@index');
Route::post('/addCategory' , 'CategoryController@addCategory');
Route::get('/manegeCategory' , 'CategoryController@manegeCategory');
Route::get('/unactive_category/{category_id}' , 'CategoryController@unactive_category');
Route::get('/active_category/{category_id}' , 'CategoryController@active_category');
 Route::get('/category/edit/{category_id}','CategoryController@editCategory');
Route::post('/category/update','CategoryController@updateCategory');
Route::get('/category/delete/{category_id}','CategoryController@deleteCategory');




//Product Route...............
Route::get('/add-manufacture' , 'ManufactureController@index');
Route::post('/addManufacture' , 'ManufactureController@addManufacture');
Route::get('/manegeManufacture' , 'ManufactureController@manegeManufacture');
Route::get('/unactive_manufacture/{manufacture_id}' , 'ManufactureController@unactive_manufacture');
Route::get('/active_manufacture/{manufacture_id}' , 'ManufactureController@active_manufacture');
 Route::get('/manufacture/edit/{manufacture_id}','ManufactureController@editManufacture');
Route::post('/manufacture/update','ManufactureController@updateManufacture');
Route::get('/manufacture/delete/{manufacture_id}','ManufactureController@deleteManufacture');



//Product Route.................
Route::get('/addProduct' , 'ProductController@index');

Route::get('/manegeProduct' , 'ProductController@manegeProduct');

Route::post('/saveProduct' , 'ProductController@storeProduct');
Route::get('/unactive_product/{product_id}' , 'ProductController@unactive_product');
Route::get('/active_product/{product_id}' , 'ProductController@active_product');
 Route::get('/product/edit/{product_id}','ProductController@editProduct');
Route::post('/product/update','ProductController@updateProduct');


Route::get('/product/view/{product_id}','ProductController@viewProduct');
Route::get('/product/delete/{product_id}','ProductController@deleteProduct');



//Slider Route........

Route::get('/addSlider' , 'SliderController@index');
Route::post('/saveSlider' , 'SliderController@saveSlider');
Route::get('/manegeSlider' , 'SliderController@manegeSlider');

Route::get('/unactive_slider/{slider_id}' , 'SliderController@unactive_slider');
Route::get('/active_slider/{slider_id}' , 'SliderController@active_slider');
Route::get('/slider/delete/{slider_id}','SliderController@deleteSlider');


//Order Manage Route..........
Route::get('/manegeOrder' , 'OrderController@manegeOrder');
Route::get('/viewOrder/{order_id}' , 'OrderController@viewOrder');
Route::get('/deleteOrder/{order_id}' , 'OrderController@deleteOrder');

Route::get('/unSuccess_order/{order_id}' , 'OrderController@unSuccess_order');
Route::get('/success_order/{order_id}' , 'OrderController@success_order');


