<?php $__env->startSection('title'); ?>

Admin || Manage Product

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>


<h3 style="text-align: center" class="text-success">
    
    <?php echo e(Session::get('message')); ?>

</h3>

<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a>
					<i class="icon-angle-right"></i> 
				</li>
				<li>
					<i class="icon-edit"></i>
					<a href="#">Manage Product</a>
				</li>
			</ul>

<div class="row-fluid sortable">		
	<div class="box span12">
		<div class="box-header" data-original-title>
			<h2><i class="halflings-icon user"></i><span class="break"></span>Manage Product</h2>
			<div class="box-icon">
				<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
				<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
				<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
			</div>
		</div>
		<div class="box-content">
			<table class="table table-striped table-bordered bootstrap-datatable datatable">
			  <thead>
				  <tr>
					   <th>Product ID</th>
					   <th>Product Name</th>
					  <th>Category Name</th>
					  <th>Manufacture Name</th>
					  <th>Product Image</th>				  
					  <th>Product Price</th>
					  <th>Upload Date</th>					  				  
					  <th>Publication Status</th>
					  <th>Actions</th>
				  </tr>
			  </thead>   
			  <tbody>
			  	 
				<tr>
					
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<td><?php echo e($product->product_id); ?></td>
					<td><?php echo e($product->product_name); ?></td>
					<td><?php echo e($product->category_name); ?></td>
					<td><?php echo e($product->manufacture_name); ?></td>
					<td><img src="<?php echo e(asset($product->product_image)); ?>" alt="<?php echo e($product->product_name); ?>" width="100" height="100"></td>
					<td> BDT. <?php echo e($product->product_price); ?></td>
					<td><?php echo e($product->upload_date); ?></td>
					
					
					
					
					
					
                    
					<td class="center">			


			<?php if($product->publicationStatus == 1): ?>
			<span class="label label-success"> Published </span>
				<?php else: ?>
				<span class="label label-danger"> UnPublished </span>

				<?php endif; ?>

					</td>
					<td class="center">
					<?php if($product->publicationStatus == 1): ?>
						<a class="btn btn-success" href="<?php echo e(url('/unactive_product/'.$product->product_id)); ?>">
							<i class="halflings-icon white thumbs-down"></i>  
						</a>
						<?php else: ?>
						<a class="btn btn-danger" href="<?php echo e(url('/active_product/'.$product->product_id)); ?>">
							<i class="halflings-icon white thumbs-up"></i>  
						</a>
						<?php endif; ?>


						<a class="btn btn-info" href="<?php echo e(url('/product/view/'.$product->product_id)); ?>">
							<i class="halflings-icon white eye-open"></i>  
						</a>
						<a class="btn btn-info" href="<?php echo e(url('/product/edit/'.$product->product_id)); ?>">
							<i class="halflings-icon white edit"></i>  
						</a>
						<a class="btn btn-danger" href="<?php echo e(url('/product/delete/'.$product->product_id)); ?>" id="delete">
							<i class="halflings-icon white trash"></i> 
						</a>
					</td>


				</tr>

				 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			  </tbody>
		  </table>            
		</div>
	</div><!--/span-->

</div><!--/row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>