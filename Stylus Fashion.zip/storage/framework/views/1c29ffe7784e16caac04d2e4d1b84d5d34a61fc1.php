 



<?php $__env->startSection('content'); ?>
    <section id="cart_items">
        <div class="container col-sm-12">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                  <li><a href="#">Home</a></li>
                  <li class="active">Shopping Cart</li>
                </ol>
            </div>


<h4 style="text-align: center; margin-top: 10px; margin-bottom: 10px; font-weight: bold;" class="text-success">
    
    <?php echo e(Session::get('message')); ?>

</h4>
            <div class="table-responsive cart_info">
                <table class="table table-condensed">
                    <thead>
                        <tr class="cart_menu">
                            <td class="image">Image</td>
                            <td></td>
                            <td></td>
                            <td class="description">Name</td>
                            <td class="price">Price</td>
                            <td class="quantity">Quantity</td>
                            <td class="total">Total</td>
                            <td>Action</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php $__currentLoopData = $cartProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <td class="cart_product">
                                <a href=""><img src="<?php echo e(asset($cartProduct->options->image)); ?>" alt="" width="100px" height="100px"></a>
                            </td>
                            <td></td>
                            <td></td>
                            <td class="cart_description">
                                <h4><a href=""><?php echo e($cartProduct->name); ?></a></h4>
                                <p>Web ID: <?php echo e($cartProduct->id); ?></p>
                            </td>
                            <td class="cart_price">
                                <p>BDT. <?php echo e($cartProduct->price); ?></p>
                            </td>
                            <form action="<?php echo e(url('/cart-update')); ?>" method="post" >
                                <?php echo e(csrf_field()); ?>

                            <td class="cart_quantity">
                                <div class="cart_quantity_button">
                                    
                                    <input class="cart_quantity_input" type="text" name="qty" value="<?php echo e($cartProduct->qty); ?>" autocomplete="off" size="2">

                                     <input  type="hidden" name="cart_rowId" value="<?php echo e($cartProduct->rowId); ?>" >
                                    
                                    <button class="btn btn-primary" type="submit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>

                        </button>
 
                                </div>
                            </td>
                            </form>
                            <td class="cart_total">
                                <p class="cart_total_price"> BDT. <?php echo e($cartProduct->total); ?></p>
                            </td>
                            <td class="cart_delete">
                                <a class="cart_quantity_delete" href="<?php echo e(url('/delete-cart-product/'.$cartProduct->rowId)); ?>"><i class="fa fa-times"></i></a>
                            </td>

                            
                        </tr>



                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                       
                    </tbody>
                </table>
            </div>
        </div>
    </section> <!--/#cart_items-->


<section id="do_action">
        <div class="container col-sm-12">
            
            <div class="row">
               
                <div class="col-sm-8">
                    <div class="total_area">
                        <ul>
                            <li>Cart Sub Total <span>BDT. <?php echo e(Cart::subtotal()); ?></span></li>
                            <li>Eco Tax <span>BDT. <?php echo e(Cart::tax()); ?></span></li>
                            <li>Shipping Cost <span>BDT. Free</span></li>
                            <li>Total <span>BDT. <?php echo e(Cart::total()); ?></span></li>
                        </ul>
                            <a class="btn btn-default update" href="<?php echo e(url('/')); ?>"><i class="fa fa-chevron-left "></i>CONTINUE SHOPPING</a>



                             <?php
                                    $customerId = Session::get('customerId');

                                    ?>

                                    <?php 

                                    if ($customerId != null) {
                                        ?>
                                          <a class="btn btn-default check_out" href="<?php echo e(url('/checkout')); ?>">Check Out</a>

                                        <?php
                                    }else{
                                        ?>
                                 <a class="btn btn-default check_out" href="<?php echo e(url('/loginCheck')); ?>">Check Out</a>

                                        <?php }  ?>

                            
                    </div>
                </div>
            </div>
        </div>
    </section><!--/#do_action-->       
                
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>