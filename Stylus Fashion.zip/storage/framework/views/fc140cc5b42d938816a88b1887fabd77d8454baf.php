<?php $__env->startSection('title'); ?>
Admin || Update Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>

<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a>
					<i class="icon-angle-right"></i> 
				</li>
				<li>
					<i class="icon-edit"></i>
					<a href="#">Update Product</a>
				</li>
			</ul>
			
			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon edit"></i><span class="break"></span>Update Product</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<form class="form-horizontal" enctype="multipart/form-data" method="post" action="<?php echo e(url('/product/update')); ?>" name="editProductForm">

							<?php echo e(csrf_field()); ?>

						  <fieldset>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Product Name </label>
							  <div class="controls">
								<input type="text" name="product_name" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" value="<?php echo e($productById->product_name); ?>" >

								<input type="hidden" name="productId" value="<?php echo e($productById->product_id); ?>" id="">
							  </div>
							</div>

							 <?php
						        $publishedCategory = DB::table('categories')
						        ->where('publicationStatus',1)
						        ->get();

						      ?>  

							<div class="control-group">
								<label class="control-label" for="selectError1">Category Name</label>
								
								<div class="controls">
									
								  <select id="selectError1"  name="category_id">
								  	<option value="#">Select Category Name</option>
								  	<?php $__currentLoopData = $publishedCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>
									 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  </select>
								 
								</div>
								
							  </div>
							  <?php
		                        $publishedManufacture = DB::table('manufactures')
		                        ->where('publicationStatus',1)
		                        ->get();

		                      ?>  


							  <div class="control-group">
								<label class="control-label" for="selectError1">Manufacture Name</label>
								<div class="controls">
								   <select id="selectError1"  name="manufacture_id">
								   	<option value="#">Select Manufacture Name</option>
								  	<?php $__currentLoopData = $publishedManufacture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($manufacture->manufacture_id); ?>"><?php echo e($manufacture->manufacture_name); ?></option>
									 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  </select>
								</div>
							  </div>


							<div class="control-group">
							  <label class="control-label" for="date01">Upload Date</label>
							  <div class="controls">
								<input type="text" name="upload_date" class="input-xlarge datepicker" id="date01" value="<?php echo e($productById->upload_date); ?>" >
							  </div>
							</div>

							<div class="control-group hidden-phone">
							  <label class="control-label" for="textarea2">Product Short Description</label>
							  <div class="controls">
								<textarea class="cleditor" name="product_short_description" id="textarea2" rows="2"> <?php echo e($productById->product_short_description); ?> </textarea>
							  </div>
							</div>

							<div class="control-group hidden-phone">
							  <label class="control-label" for="textarea2">Product Long Description</label>
							  <div class="controls">
								<textarea class="cleditor" name="product_long_description" id="textarea2" rows="2"> <?php echo e($productById->product_long_description); ?> </textarea>
							  </div>
							</div>
							  <div class="control-group">
							  <label class="control-label" for="typeahead">Product Price </label>
							  <div class="controls">
								<input type="number" name="product_price" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" value="<?php echo e($productById->product_price); ?>" >
							  </div>
							</div>


							<div class="control-group">
							  <label class="control-label" for="fileInput">Image</label>
							  <div class="controls">
								<input class="input-file uniform_on" accept="image/*" name="productImage" id="fileInput" type="file" >

								<img src="<?php echo e(asset($productById->product_image)); ?>" alt="<?php echo e($productById->product_name); ?>" width="30" height="30">
							  </div>
							</div>  


							<div class="control-group">
								<label class="control-label" for="selectError1">Product Size</label>
								
								<div class="controls">								
							
								  	<input type="text" name="product_size" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"  value="<?php echo e($productById->product_size); ?>">								  
								 
								</div>								
							  </div>

							  <div class="control-group">
							  <label class="control-label" for="typeahead">Product Quantity </label>
							  <div class="controls">
								<input type="number" name="product_quantity" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" value="<?php echo e($productById->product_quantity); ?>" >
							  </div>
							</div>

							



							<div class="control-group">
							  <label class="control-label" for="typeahead">Product Color </label>
							  <div class="controls">
								<input type="text" name="product_color" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" value="<?php echo e($productById->product_color); ?>">
							  </div>
							</div>
							


							<div class="control-group">
							  <label class="control-label" >Publication Status </label>
							  <div class="controls">
								<select name="publicationStatus" id="" class="form-control">
					    			<option value="#">Select Publication Status</option>
									<option value="1">Published</option>
									<option value="0">Unpublished</option>
								</select>
							  </div>
							</div>


							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">Update Product</button>
							  <!-- <button type="reset" class="btn" href="<?php echo e(url('/manegeProduct')); ?>">Cancel</button> -->

							  <a href="<?php echo e(url('/manegeProduct')); ?>" class="btn btn-danger">Cancel</a>
							</div>
						  </fieldset>
						</form>   

					</div>
				</div><!--/span-->

				<script>
					document.forms['editProductForm'].elements['publicationStatus'].value=<?php echo e($productById->publicationStatus); ?>

					document.forms['editProductForm'].elements['category_id'].value=<?php echo e($productById->category_id); ?>

					document.forms['editProductForm'].elements['manufacture_id'].value=<?php echo e($productById->manufacture_id); ?>


					
				</script>

			</div><!--/row-->

			
			


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>