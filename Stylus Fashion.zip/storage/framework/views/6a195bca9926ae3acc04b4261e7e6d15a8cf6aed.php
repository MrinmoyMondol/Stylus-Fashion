<!DOCTYPE html>
<html lang="en">


<head>
	
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: CSS -->
	
	<link id="bootstrap-style" href="<?php echo e(asset('backEnd/css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('backEnd/css/bootstrap-responsive.min.css')); ?>" rel="stylesheet">
	<link id="base-style" href="<?php echo e(asset('backEnd/css/font-awesome.min.css')); ?>" rel="stylesheet">
	<link id="base-style" href="<?php echo e(asset('backEnd/css/style.css')); ?>" rel="stylesheet">
	<link id="base-style-responsive" href="<?php echo e(asset('backEnd/css/style-responsive.css')); ?>" rel="stylesheet">




	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;subset=latin,cyrillic-ext,latin-ext' rel='stylesheet' type='text/css'>
	<!-- end: CSS -->
	

	<link rel="shortcut icon" href="<?php echo e(asset('backEnd/img/favicon.ico')); ?>">
	<!-- end: Favicon -->
	
		
		
		
</head>

<body>
		<!-- start: Header -->
	<?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<div class="container-fluid-full">
		<div class="row-fluid">
				
			<?php echo $__env->make('admin.include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			
			
			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<?php echo $__env->yieldContent('admin_content'); ?>
       

			</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->
		
	<div class="modal hide fade" id="myModal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<p>Here settings can be configured...</p>
		</div>
		<div class="modal-footer">
			<a href="#" class="btn" data-dismiss="modal">Close</a>
			<a href="#" class="btn btn-primary">Save changes</a>
		</div>
	</div>
	
	<div class="clearfix"></div>
	
	<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2018 <a href="#" alt="Bootstrap Themes"> </a></span>
			<span class="hidden-phone" style="text-align:right;float:right">Developed By: <a href="#" >MM CHANCHAL</a></span>
		</p>

	</footer>
	




	<!-- start: JavaScript-->

		<script src="<?php echo e(asset('backEnd/js/jquery-1.9.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/js/jquery-migrate-1.0.0.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery-ui-1.10.0.custom.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.ui.touch-punch.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/modernizr.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/bootstrap.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.cookie.js')); ?>"></script>
	
		<script src='<?php echo e(asset('backEnd/js/fullcalendar.min.js')); ?>'></script>
	
		<script src='<?php echo e(asset('backEnd/js/jquery.dataTables.min.js')); ?>'></script>

		<script src="<?php echo e(asset('backEnd/js/excanvas.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/js/jquery.flot.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/js/jquery.flot.pie.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/js/jquery.flot.stack.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/js/jquery.flot.resize.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.chosen.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.uniform.min.js')); ?>"></script>
		
		<script src="<?php echo e(asset('backEnd/js/jquery.cleditor.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.noty.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.elfinder.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.raty.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.iphone.toggle.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.uploadify-3.1.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.gritter.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.imagesloaded.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.masonry.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.knob.modified.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/jquery.sparkline.min.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/counter.js')); ?>"></script>
	
		<script src="<?php echo e(asset('backEnd/js/retina.js')); ?>"></script>
		<script src="<?php echo e(asset('backEnd/js/bootbox.min.js')); ?>"></script>

		<script src="<?php echo e(asset('backEnd/js/custom.js')); ?>"></script>


		<script>
			$(document).on("click","#delete",function (e) {
				e.preventDefault();
				var link = $(this).attr("href");
				bootbox.confirm("Are you want to delete..!!",function(confirmed){
					if(confirmed){
						window.location.href = link;
					};
				});
			});
		</script>


		
	<!-- end: JavaScript-->
	
</body>


</html>
