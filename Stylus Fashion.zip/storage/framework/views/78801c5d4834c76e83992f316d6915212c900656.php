<?php $__env->startSection('content'); ?>

<p>Your Order is Successfully Completed...!!!</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>