<!-- start: Main Menu -->
<div id="sidebar-left" class="span2">
	<div class="nav-collapse sidebar-nav">
		<ul class="nav nav-tabs nav-stacked main-menu">
			<li>
				<a href="<?php echo e(url('/dashboard')); ?>"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a>
			</li>	
			
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Category</span><span class="label label-important"> 2 </span></a>
				<ul>
					<li>
						<a class="submenu" href="<?php echo e(url('/add-category')); ?>"><i class="icon-file-alt"></i><span class="hidden-tablet"> Add Category</span></a>
					</li>
					<li>
						<a class="submenu" href="<?php echo e(url('/manegeCategory')); ?>"><i class="icon-file-alt"></i><span class="hidden-tablet"> Manage Category</span></a>
					</li>
					
				</ul>	
			</li>
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Brand</span><span class="label label-important"> 2 </span></a>
				<ul>
					<li>
						<a class="submenu" href="<?php echo e(url('/add-manufacture')); ?>"><i class="icon-file-alt"></i><span class="hidden-tablet"> Add Brand</span></a>
					</li>
					<li>
						<a class="submenu" href="<?php echo e(url('/manegeManufacture')); ?>"><i class="icon-file-alt"></i><span class="hidden-tablet"> Manage Brand</span></a>
					</li>
					
				</ul>	
			</li>
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Product</span><span class="label label-important"> 2 </span></a>
				<ul>
					<li>
						<a class="submenu" href="<?php echo e(url('/addProduct')); ?>"><i class="icon-file-alt"></i><span class="hidden-tablet"> Add Product</span></a>
					</li>
					<li>
						<a class="submenu" href="<?php echo e(url('/manegeProduct')); ?>"><i class="icon-file-alt"></i><span class="hidden-tablet"> Manage Product</span></a>
					</li>
					
				</ul>	
			</li>

			
			
			<li>
				<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Slider</span><span class="label label-important"> 2 </span></a>
				<ul>
					<li>
						<a class="submenu" href="<?php echo e(url('/addSlider')); ?>"><i class="icon-file-alt"></i><span class="hidden-tablet"> Add Slider</span></a>
					</li>
					<li>
						<a class="submenu" href="<?php echo e(url('/manegeSlider')); ?>"><i class="icon-file-alt"></i><span class="hidden-tablet"> Manage Slider</span></a>
					</li>
					
				</ul>	
			</li>

			<li>
				<a href="<?php echo e(url('/manegeOrder')); ?>"><i class="icon-folder-open"></i><span class="hidden-tablet"> Order Manage</span></a>
			</li>
			


			<li>
				<a href="<?php echo e(url('')); ?>"><i class="icon-folder-open"></i><span class="hidden-tablet"> Social Link</span></a>
			</li>
			<li>
				<a href="<?php echo e(url('/shopLogo')); ?>"><i class="icon-star"></i><span class="hidden-tablet"> Shop Name</span></a>
			</li>
			<li>
				<a href="<?php echo e(url('')); ?>l"><i class="icon-lock"></i><span class="hidden-tablet"> Delivery Man</span></a>
			</li>
		</ul>
	</div>
</div>
<!-- end: Main Menu -->