<?php

namespace App\Providers;
use Illuminate\Support\Facades\Schema;
use View;
use DB;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

         View::composer('layout',function($view){
           // $publishedCategories = Category::where('publicationStatus',1)->get();
           //  $view->with('publishedCategories', $publishedCategories );


            $logo = DB::table('logos')
                ->orderBy('logo_id','desc')                
                ->first();
            $view->with('logo',$logo);

         });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
