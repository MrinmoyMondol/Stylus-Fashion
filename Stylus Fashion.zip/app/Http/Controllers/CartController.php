<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use Cart;

class CartController extends Controller
{
   // public function index()
   // {
   // 	return view('pages.showCart');
   // }


   public function addToCart(Request $request)
   {
   	    	//dd($request->all());



    	$product_id = $request->product_id;
    	$productById = Product::where('product_id',$product_id)->first();

    	 Cart::add([
    		'id'=>$product_id,
    		'name'=>$productById->product_name,
    		'price'=>$productById->product_price,
    		
    		'qty'=>$request->qty,
    		'options' => ['image' =>$productById->product_image, ]



    	]);

    	// echo "<pre>";
    	// print_r($cartProduct);
    	// exit();






    	  return redirect('/showCart');

   }

    public function showCart()
    {
    	$cartProducts = Cart::Content();
    	// echo "<pre>";
    	// print_r($cartProducts);
    	// exit();

    	  return view('pages.showCart',['cartProducts'=>$cartProducts]);
    }


     public function updateCart(Request $request)
    {
    	Cart::update($request->cart_rowId,$request->qty);

    	return redirect('/showCart')->with('message','Cart Product Update Successfully..!!');


    }


     public function deleteCart($rowId)
    {
    	Cart::remove($rowId);
    	return redirect('/showCart')->with('message','Cart Product  Delete Successfully..!!');

    }
}
