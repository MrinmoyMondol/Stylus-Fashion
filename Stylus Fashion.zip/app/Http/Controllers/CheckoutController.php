<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use App\Shipping;
use Session;
use DB;


class CheckoutController extends Controller
{
    public function login_check()
    {
    	return view('pages.login');
    }


    public function customer_registration(Request $request)
    {
    	 // dd($request->all());
    	$customer = new Customer;
    	$customer->customerName  = $request->customerName;
    	$customer->customerEmail = $request->customerEmail;
    	$customer->customerPhone  = $request->customerPhone;
    	$customer->customerPassword = md5($request->customerPassword);
    	$customer->save();

    	

    	$customerId = $customer->customerId;

    	Session::put('customerId',$customerId); 

    	
    	Session::put('customerName', $request->customerName);

    	return redirect('/checkout');
    }

    public function checkOut()
    {
    	return view('pages.checkOut');
    }


    public function login_customer(Request $request)
    {
    	$customerEmail = $request->customerEmail;
    	$customerPassword = md5($request->customerPassword);
        $customerId =  Customer::where ('customerEmail',$customerEmail)
                    ->where ('customerPassword',$customerPassword)
                    ->first();

            $customerId = $customerId->customerId;
            
    	 if ($customerId) {
             Session::put('customerId',$customerId);       

    	 	 return redirect('/checkout');

    	 }

    	 else{
    	 	
    	 	return redirect('/loginCheck')->with('message','Email Or Password Invalid..!!');
    	 }
    }   



    public function saveShippingDetails( Request $request)
    {
    	// dd($request->all());
    	$shipping = new Shipping;
    	$shipping->shipping_email = $request->shipping_email;
    	$shipping->shipping_fistName = $request->shipping_fistName;
    	$shipping->shipping_lastName = $request->shipping_lastName;
    	$shipping->shipping_address  = $request->shipping_address;
    	$shipping->shipping_mobile  = $request->shipping_mobile;
    	$shipping->shipping_city    = $request->shipping_city;
    	$shipping->save();

    	$shippingId = $shipping->shipping_id;
    	Session::put('shipping_id',$shippingId);

    	return redirect('/payment');
    }



     public function customerLogout()
    {
    	Session::flush();

    	return redirect('/');
    }





}
