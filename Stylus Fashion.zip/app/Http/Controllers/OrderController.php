<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Cart;
use App\Payment;
use App\Product;
use App\Order;
use App\OrderDetail;
use App\Shipping;
use App\Customer;
use Session;
use DB;

class OrderController extends Controller
{
    public function manegeOrder()
    {
    	 $orders= DB::table('orders')
        ->join('customers','orders.customerId','=','customers.customerId')
        ->select('orders.*','customers.customerName')
        ->get();


    	return view('admin.Order.manegeOrder',['orders'=> $orders]);
    }


    public function viewOrder($order_id)
    {
    	// return $order_id;


    	$orderById = DB::table('orders')
        ->join('customers','orders.customerId','=','customers.customerId')
        ->join('order_details','orders.order_id','=','order_details.order_id')
        ->join('shippings','orders.shipping_id','=','shippings.shipping_id')
        ->select('orders.*', 'order_details.*','shippings.*','customers.*')
        ->where('orders.order_id',$order_id)
        ->first();

        // echo "<pre>";
        // print_r($orderById);
        // echo "</pre>";
        // exit();

    	return view('admin.Order.viewOrder',['orderById'=>$orderById]);
    }


    public function unSuccess_order($order_id)
        {
            DB::table('orders')
            ->where('order_id',$order_id)
            ->update(['order_status'=> 'success']);

            $arr=array();

            //  $orders= Order::whereIn('order_id', $arr['order_id'])->get();
            //     foreach($orders as $order)
            //     {
            //         $order->fill(['order_status' => 'pending'])->save(); 
            //     }

            return redirect('/manegeOrder');
        }



public function success_order($order_id)
        {
           DB::table('orders')
            ->where('order_id',$order_id)
            ->update(['order_status'=>'pending']);

            // $orders= Order::whereIn('order_id', $arr['order_id'])->get();
            //     foreach($orders as $order)
            //     {
            //         $order->fill(['order_status' => 'success'])->save(); 
            //     }

            return redirect('/manegeOrder');
        }
 

    public function deleteOrder($order_id)
    {
    	$order = Order::find($order_id);
   	 $order->delete();
   	 return redirect('/manegeOrder')->with('message','Order Cancellation Successfully..!!');

    }
}
