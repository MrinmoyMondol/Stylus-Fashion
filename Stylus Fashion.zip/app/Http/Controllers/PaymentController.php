<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Cart;
use App\Payment;
use App\Product;
use App\Order;
use App\OrderDetail;
use App\Shipping;
use App\Customer;
use Session;


class PaymentController extends Controller
{
    public function index()
    {
    	$cartProducts = Cart::Content();
    	return view('pages.payment',['cartProducts'=>$cartProducts]);
    }

    public function orderPlace(Request $request)
    {
    	$paymentType = $request->payment_gateway;

        $payment = new Payment();
        // dd($request->all());
        $payment->payment_method = $paymentType;
        $payment->payment_status = 'pending';
        $payment->save();

        $payment_id = $payment->payment_id;
        Session::put('payment_id',$payment_id);

        $order= new Order();
        $cartProducts = Cart::content();
        
        $order->customerId = Session::get('customerId');
        $order->shipping_id = Session::get('shipping_id');
        $order->payment_id = Session::get('payment_id');
        $order->order_total =Cart::total();
        $order->order_status ='pending';

        $order->save();

        $order_id = $order->order_id;
        Session::put('order_id',$order_id);

        $orderDetail = new OrderDetail();
        $cartProducts = Cart::content();
        foreach ($cartProducts as $CartProduct) {
            $orderDetail-> order_id   = Session::get('order_id');
            $orderDetail-> product_id = $CartProduct->id;
            $orderDetail-> product_name = $CartProduct->name;
            $orderDetail-> product_price  = $CartProduct->price;
            $orderDetail-> product_sales_quantity = $CartProduct->qty;

            $orderDetail->save();

        if ($paymentType =='handCash') {
            Cart::remove($CartProduct->rowId);
            // echo "Order Successfull";
             return redirect('/my-home');

           
        }

         else if ($paymentType =='bKash') {
            echo 'Under Construction B-kash Payment';
        }
        else if ($paymentType =='card') {
        echo 'Under Construction Card Payment';

        }

        else if ($paymentType =='payza') {
        echo 'Under Construction Payza Payment';

        }
    }

}


public function myHome()
{
     return view('pages.my-home');
}

   


}

