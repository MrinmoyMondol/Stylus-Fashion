<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use DB;
use Session;

class CategoryController extends Controller
{
    public function index()
    {
     

    	return view('admin.Category.addCategory');
    }

    public function addCategory(Request $request)
    {

      
      
    	$category = new Category();
    	$category->category_name = $request->category_name;
    	$category->category_description =strip_tags($request->category_description);
    	$category->publicationStatus = $request->publicationStatus;
    	$category->save();

    	//dd($request->all());

    	return redirect('/manegeCategory')->with('message','Category Save Successfully..!!');
    	
    }

      public function manegeCategory()
    {
      
    	$categories = Category::all();
    	return view('admin.Category.manageCategory',['categories'=>$categories]);

    }


    	public function unactive_category($category_id)
    	{
    		DB::table('categories')
    		->where('category_id',$category_id)
    		->update(['publicationStatus'=>0]);

    		return redirect('/manegeCategory');
    	}



public function active_category($category_id)
    	{
    		DB::table('categories')
    		->where('category_id',$category_id)
    		->update(['publicationStatus'=>1]);

    		return redirect('/manegeCategory');
    	}

       public function editCategory($category_id)
   {
   		//return $category_id;
    

   	$categoryById = Category::where('category_id',$category_id)->first();
	return view('admin.Category.editCategory',['categoryById'=>$categoryById]);

    	//return redirect('/catagory/edit')->with('message','Category Info Updated Successfully..!!');

   }


    public function updateCategory(Request $request)
   {
   	 //dd($request->all());   	


    	$category = Category::find($request->category_id);
    	$category->category_name = $request->category_name;
    	$category->category_description = strip_tags($request->category_description);
    	$category->publicationStatus = $request->publicationStatus;
    	$category->save();

    	return redirect('/manegeCategory')->with('message','Category Info Update Successfully..!!');

    }


   		
   public function deleteCategory($category_id)
   {
   	 $category = Category::find($category_id);
   	 $category->delete();
   	 return redirect('/manegeCategory')->with('message','Category Info Delete Successfully..!!');


   }



  public function AdminAuthCheck()
    {
        $admin_id= Session::get('admin_id');

        if ($admin_id) {
            return ;
        }

        else{
            return redirect('/admin')->send();
        }
    }

}
