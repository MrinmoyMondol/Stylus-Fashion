<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Slider;

use Session;
use DB;
session_start();

class SliderController extends Controller
{
    public function index()
    {
    	return view('admin.Slider.addSlider');
    }


    public function saveSlider(Request $request)
    {
    	// return $request->all();

    	  $sliderImage = $request->file('sliderImage');
       // echo '<pre>';
       // print_r($sliderImage);
       // exit();

       $imageName= $sliderImage->getClientOriginalName();
       // echo $imageName;

        $uploadPath='sliderImage/';


       $sliderImage->move($uploadPath,$imageName);
       $imageURL=$uploadPath.$imageName;      

       $this->saveSliderInfo($request,$imageURL);


       return redirect('/manegeSlider')->with('message','Slider Info Save Successfully..!!');    
    }


      protected function saveSliderInfo($request,$imageURL)
    {
    	
		$slider = new Slider;
		$slider->slider_image = $imageURL ;
		$slider->publicationStatus = $request->publicationStatus;
		$slider->save();
    }


    public function manegeSlider()
    {
    	$sliders = Slider::all();

    	return view('admin.Slider.manegeSlider',['sliders'=>$sliders]);
    }



    // Product UnActive...............

    public function unactive_slider($slider_id)
    	{
    		DB::table('sliders')
    		->where('slider_id',$slider_id)
    		->update(['publicationStatus'=>0]);

    		return redirect('/manegeSlider');
    	}


// Product Active...............

public function active_slider($slider_id)
    	{
    		DB::table('sliders')
    		->where('slider_id',$slider_id)
    		->update(['publicationStatus'=>1]);

    		return redirect('/manegeSlider');
    	}

  //Delete Slider...........

    	public function deleteSlider($slider_id)
    {
         $slider = Slider::find($slider_id);
         $slider->delete();
         return redirect('/manegeSlider')->with('message','Slider Info Delete Successfully..!!');
    }


}
