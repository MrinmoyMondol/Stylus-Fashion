<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Manufacture;
use DB;
use Session;

class ManufactureController extends Controller
{
   public function index()
    {
      $this->AdminAuthCheck();
    	return view('admin.Manufacture.addManufacture');
    }

    public function addManufacture(Request $request)
    {
      $this->AdminAuthCheck();

    	$manufacturer = new Manufacture();
    	$manufacturer->manufacture_name  = $request->manufacturer_name;
    	$manufacturer->manufacture_description  =strip_tags($request->manufacturer_description);
    	$manufacturer->publicationStatus = $request->publicationStatus;
    	$manufacturer->save();

    	//dd($request->all());

    	return redirect('/manegeManufacture')->with('message','Manufacturer Save Successfully..!!');
    	
    }

      public function manegeManufacture()
    {
      $this->AdminAuthCheck();
    	$manufacturers = Manufacture::all();
    	return view('admin.Manufacture.manegeManufacture',['manufacturers'=>$manufacturers]);

    }


    	public function unactive_manufacture($manufacture_id)
    	{
    		DB::table('manufactures')
    		->where('manufacture_id',$manufacture_id)
    		->update(['publicationStatus'=>0]);

    		return redirect('/manegeManufacture');
    	}



public function active_manufacture($manufacture_id)
    	{
    		DB::table('manufactures')
    		->where('manufacture_id',$manufacture_id)
    		->update(['publicationStatus'=>1]);

    		return redirect('/manegeManufacture');
    	}


      

       public function editManufacture($manufacture_id)
   {
   		//return $category_id;
    $this->AdminAuthCheck();

   	$manufactureById = Manufacture::where('manufacture_id',$manufacture_id)->first();
	return view('admin.Manufacture.editManufacture',['manufactureById'=>$manufactureById]);

    	//return redirect('/catagory/edit')->with('message','Category Info Updated Successfully..!!');

   }


    public function updateManufacture(Request $request)
   {
   	 //dd($request->all());   		

    	$manufacture = Manufacture::find($request->manufacture_id);
    	$manufacture->manufacture_name = $request->manufacture_name;
    	$manufacture->manufacture_description = strip_tags($request->manufacture_description);
    	$manufacture->publicationStatus = $request->publicationStatus;
    	$manufacture->save();

    	return redirect('/manegeManufacture')->with('message','Manufacture Info Update Successfully..!!');

    }


   		
   public function deleteManufacture($manufacture_id)
   {
   	 $manufacture = Manufacture::find($manufacture_id);
   	 $manufacture->delete();
   	 return redirect('/manegeManufacture')->with('message','Manufacture Info Delete Successfully..!!');


   }


   public function AdminAuthCheck()
    {
        $admin_id= Session::get('admin_id');

        if ($admin_id) {
            return ;
        }

        else{
            return redirect('/admin')->send();
        }
    }


  

}
