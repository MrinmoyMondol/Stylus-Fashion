<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;
use App\Manufacture;
use Session;
use DB;
session_start();

class ProductController extends Controller
{
    public function index()
    {
        $this->AdminAuthCheck();
    	return view('admin.Product.addProduct');
    }



//Product Upload....................

    public function storeProduct(Request $request)
    {
    	//return $request->all();


    	  $productImage = $request->file('productImage');
       // echo '<pre>';
       // print_r($productImage);

       $imageName= $productImage->getClientOriginalName();
       //echo $imageName;

        $uploadPath='productImage/';


       $productImage->move($uploadPath,$imageName);
       $imageURL=$uploadPath.$imageName;      

       $this->saveProductInfo($request,$imageURL);


       return redirect('/manegeProduct')->with('message','Product Info Save Successfully..!!');    	
   }


    protected function saveProductInfo($request,$imageURL)
    {
    	$product = new Product;
		$product->product_name = $request->product_name;
    	$product->category_id = $request->category_id;
    	$product->manufacture_id = $request->manufacture_id;

    	$product->upload_date = $request-> upload_date ;
    	$product->product_short_description = strip_tags($request->product_short_description) ;
    	$product->product_long_description = strip_tags($request->product_long_description) ;
    	$product->product_price = $request->product_price;
		$product->product_image = $imageURL;
    	
	    $product->product_size = $request->product_size ;
		$product->product_quantity = $request->product_quantity ;
  		
		$product->product_color = $request->product_color ;   	
    	
    	$product->publicationStatus = $request->publicationStatus;
    	 $product->save();
    }


//Product Manege..................

   public function manegeProduct()
    {
        $products= DB::table('products')
        ->join('categories','products.category_id','=','categories.category_id')
        ->join('manufactures','products.manufacture_id','=','manufactures.manufacture_id')
        ->select('products.product_id','products.product_name','products.upload_date','products.product_price','products.product_quantity','products.publicationStatus', 'categories.category_name', 'manufactures.manufacture_name','products.product_color','products.product_size','products.product_image')
        ->get();
        // echo "<pre>";
        // print_r($product);
        // exit(); 


        //$product = Product::all();
        return view('admin.Product.manegeProduct',['products'=>$products]);
    }


// Product UnActive...............

    public function unactive_product($product_id)
    	{
    		DB::table('products')
    		->where('product_id',$product_id)
    		->update(['publicationStatus'=>0]);

    		return redirect('/manegeProduct');
    	}


// Product Active...............

public function active_product($product_id)
    	{
    		DB::table('products')
    		->where('product_id',$product_id)
    		->update(['publicationStatus'=>1]);

    		return redirect('/manegeProduct');
    	}



//Product Edit...............

       public function editProduct($product_id)
  		 {
   		//return $product_id;

   	$productById = Product::where('product_id',$product_id)->first();
	return view('admin.Product.editProduct',['productById'=>$productById]);

    	//return redirect('/catagory/edit')->with('message','Category Info Updated Successfully..!!');

   }





   //Product Update.............

    public function updateProduct(Request $request)
    {
    

    $imageURL= $this->imageExistStatus($request);  
    $this->updateProductInfo($request,$imageURL);
       return redirect('/manegeProduct')->with('message','Product Update  Successfully..!!');
     }


private function imageExistStatus($request)
{ 
    $productById = Product::where('product_id',$request->productId)->first();
    
    $productImage= $request->file('productImage');

    if ($productImage) {
        $oldImageURL = $productById->product_image;

        unlink($oldImageURL);
        $imageName= $productImage->getClientOriginalName();
        //echo $imageName;

         $uploadPath='productImage/';


         $productImage->move($uploadPath,$imageName);
          $imageURL=$uploadPath.$imageName;

         
         
         }

         else {
            $imageURL = $productById->product_image;

         }
         return $imageURL;
}


     protected function updateProductInfo($request,$imageURL)
    {
        $product =Product::find($request->productId);      
		$product->product_name = $request->product_name;
    	$product->category_id = $request->category_id;
    	$product->manufacture_id = $request->manufacture_id;

    	$product->upload_date = $request-> upload_date ;
    	$product->product_short_description = strip_tags($request->product_short_description) ;
    	$product->product_long_description = strip_tags($request->product_long_description) ;
    	$product->product_price = $request->product_price;
		$product->product_image = $imageURL;
    	
	    $product->product_size = $request->product_size ;
		$product->product_quantity = $request->product_quantity ;
  		
		$product->product_color = $request->product_color ;   	
    	
    	$product->publicationStatus = $request->publicationStatus;
    	 $product->save();
    }



    //Product view..........

    public function viewProduct($product_id)
    {
        $productById = DB::table('products')
         ->join('categories','products.category_id','=','categories.category_id')
        ->join('manufactures','products.manufacture_id','=','manufactures.manufacture_id')
        ->select('products.*', 'categories.category_name', 'manufactures.manufacture_name')
        ->where('products.product_id',$product_id)
        ->first();

        // echo "<pre>";
        // print_r($productById);
        // exit();


            return view('admin.Product.viewProduct',['product'=> $productById]);
    }


 public function deleteProduct($product_id)
    {
         $product = Product::find($product_id);
         $product->delete();
         return redirect('/manegeProduct')->with('message','Product Info Delete Successfully..!!');
    }



    public function AdminAuthCheck()
    {
        $admin_id= Session::get('admin_id');

        if ($admin_id) {
            return ;
        }

        else{
            return redirect('/admin')->send();
        }
    }













   
}
