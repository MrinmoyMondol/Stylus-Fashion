<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use Illuminate\Support\Facedes\Rredirect;
use App\Http\Controllers\Redirect;

session_start();
class AdminController extends Controller
{
     public function index()
    {

    	return view('admin.admin_login');
    }


   


     public function dashboard(Request $request)
    {
        $admin_email=$request->admin_email;
        $admin_password=md5($request->admin_password);
        $result=DB::table('tbl_admin')
                ->where('admin_email',$admin_email)
                ->where('admin_password',$admin_password)
                ->first();
               
            if ($result) {
                   Session::put('admin_name',$result->admin_name);
                   Session::put('admin_id',$result->admin_id);
                   return redirect('/dashboard');
               }else{                
                   Session::put('messege','Email or Password Invalid');
                   return redirect('/admin'); 
               }   
    }



public function shopLogo()
{
  return view('admin.Logo.uploadLogo');
}


public function saveLogo(Request $request)
{
  // dd($request->all());
    $logoImage = $request->file('logoImage');
       // echo '<pre>';
       // print_r($logoImage);

       $imageName= $logoImage->getClientOriginalName();
       // echo $imageName;

        $uploadPath='logoImage/';


       $logoImage->move($uploadPath,$imageName);
       $imageURL=$uploadPath.$imageName;      

      //  // $this->saveProductInfo($request,$imageURL);

        $data=array();
        $data['logo_image'] =$imageURL ;
        DB::table('logos')->insert($data);


        return redirect('/shopLogo')->with('message','Logo upload Successfully..!!');     
}



     
}
