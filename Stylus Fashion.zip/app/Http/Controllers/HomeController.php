<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;
use App\Manufacture;
use Session;
use DB;

session_start();

class HomeController extends Controller
{
    public function index()
    {
    	 $publishProducts= DB::table('products')
        ->join('categories','products.category_id','=','categories.category_id')
        ->join('manufactures','products.manufacture_id','=','manufactures.manufacture_id')
        ->select('products.product_id','products.product_name','products.upload_date','products.product_price','products.product_quantity','products.publicationStatus', 'categories.category_name', 'manufactures.manufacture_name','products.product_color','products.product_size','products.product_image')
        ->where('products.publicationStatus',1)
        ->limit(6)
        ->get();

    	return view('pages.home_content' ,['publishProducts'=>$publishProducts]);


   //  	$manage_publish_product = view('pages.home_content')
   //  							-with('publishProducts',$publishProducts);
			// return view('layout')
			// ->with('pages.home_content',$manage_publish_product);
    }



    public function showProductByCategory($category_id)
    {
        // echo $category_id;

        $publishedCategoryProducts = Product::where('category_id',$category_id)
                                 ->where('publicationStatus',1)
                                 ->get();


return view('pages.categoryByProduct' ,['publishedCategoryProducts'=>$publishedCategoryProducts ]);


    } 



    public function showProductByManufacture($manufacture_id)
    {
         // echo $manufacture_id;

        $publishedManufactureProducts = Product::where('manufacture_id',$manufacture_id)
                                 ->where('publicationStatus',1)
                                 ->get();


return view('pages.manufactureByProduct' ,['publishedManufactureProducts'=>$publishedManufactureProducts ]);


    }


    public function viewProduct($product_id)
    {
       // return $product_id;
       // $ProductById= DB::table('products')
       //  ->join('categories','products.category_id','=','categories.category_id')
       //  ->join('manufactures','products.manufacture_id','=','manufactures.manufacture_id')
       //  ->select('products.product_id','products.product_name','products.product_price','categories.category_name', 'manufactures.manufacture_name','products.product_color','products.product_size','products.product_image')
       //  ->where('products.publicationStatus',1)       
       //  ->first();

        $ProductById = Product::where('product_id',$product_id)
        ->join('categories','products.category_id','=','categories.category_id')
        ->join('manufactures','products.manufacture_id','=','manufactures.manufacture_id')
        ->first();

       //return $ProductById;
     return view('pages.productDetails',['ProductById'=>$ProductById ]);
    }


   
}
