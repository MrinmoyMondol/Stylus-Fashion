<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use Illuminate\Support\Facedes\Rredirect;
use App\Http\Controllers\Redirect;
session_start();

class SuperAdminController extends Controller
{
   


    public function index()
    {
    	 // $this->AdminAuthCheck();
    	return view('admin.dashboard');
    }



     public function logout()
    {
    	Session::flush();

    	return redirect('/admin')->with('message','You are Successfully Loged Out..!!');
    }


    public function AdminAuthCheck()
    {
    	$admin_id= Session::get('admin_id');

    	// echo "<pre>";
    	// print_r($admin_id);
    	// exit();

    	if ($admin_id) {
    		return view('admin.dashboard');
    	}

    	else{
    		return redirect('/admin')->send();
    	}
    }
}
